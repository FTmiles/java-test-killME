public enum Lytis {
    VYRAS,
    MOTERIS,
    NEZINOMA
}
