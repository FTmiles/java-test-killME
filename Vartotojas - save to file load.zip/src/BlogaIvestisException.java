public class BlogaIvestisException {

}
